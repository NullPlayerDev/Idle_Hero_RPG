using System;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Button = UnityEngine.UIElements.Button;

/// <summary>
/// Orchestrates the full game loop:
///   1. SetupForLevel  → tells HeroSelectionManager which heroes are unlocked
///   2. Player picks   → UI calls ConfirmHeroSelection() when ready
///   3. StartCombat    → spawns selected heroes + level enemies, starts battle
///   4. HandleStageEnded → advances level, loops back to step 1
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    // -------------------------------------------------------------------------
    // Inspector
    // -------------------------------------------------------------------------

    [SerializeField] private GameObject rewardSystem;
    [SerializeField] private GameObject combatSystem;
    [SerializeField] private List<int> selectedPlayersId = new List<int>();
    // -------------------------------------------------------------------------
    // Runtime references
    // -------------------------------------------------------------------------

    private CombatSystem      _combatSystem;
    private RewardCalculator  _rewardCalculator;
    private HeroSelectionManager _selectionManager;

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    private int  _currentLevel  = 1;
    private bool _isLoopEnded   = false;
    private int  _totalStagesWon = 0;

    // -------------------------------------------------------------------------
    // Events
    // -------------------------------------------------------------------------

    public event Action OnStageEnded;
    public event Action OnLoopEnded;

    /// <summary>Fired when the selection screen should open for a new level.</summary>
    public event Action<int> OnSelectionPhaseStarted;   // passes current level

    /// <summary>Fired when combat actually begins (selection confirmed).</summary>
    public event Action OnCombatStarted;

    // -------------------------------------------------------------------------
    // Unity Lifecycle
    // -------------------------------------------------------------------------
    public List<int> SelectedPlayersId
    {
        get => selectedPlayersId;
        set => selectedPlayersId = value;
    }
    private void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else { Destroy(gameObject); return; }
    }

    void Start()
    {
        _combatSystem     = combatSystem.GetComponent<CombatSystem>();
        _rewardCalculator = rewardSystem.GetComponent<RewardCalculator>();
        _selectionManager = HeroSelectionManager.Instance;

        if (_selectionManager == null)
            Debug.LogError("[GameManager] HeroSelectionManager instance not found!");

        _combatSystem.OnStageEnded += HandleStageEnded;

        // Kick off level 1 selection
        BeginSelectionPhase(_currentLevel);
    }

    private void OnDestroy()
    {
        if (_combatSystem != null)
            _combatSystem.OnStageEnded -= HandleStageEnded;
    }

    // -------------------------------------------------------------------------
    // Public API — called by UI
    // -------------------------------------------------------------------------

    /// <summary>
    /// Call this from your hero-selection UI when the player taps "Start Battle".
    /// Does nothing if the player hasn't selected at least one hero.
    /// </summary>
    public void ConfirmHeroSelection()
    {
        if (_selectionManager == null) return;

        if (!_selectionManager.HasMinimumSelection)
        {
            Debug.LogWarning("[GameManager] Player must select at least one hero before starting.");
            return;
        }

        Debug.Log($"[GameManager] Selection confirmed — starting combat for level {_currentLevel}.");
        StartCombat();
    }

    // -------------------------------------------------------------------------
    // Scene transition helpers
    // -------------------------------------------------------------------------

    public void CombatSceneTransition()
    {
        SceneManager.LoadScene("CombatScene");
    }

    public void DeleteGame()
    {
        PlayerPrefs.DeleteAll();
        Debug.Log("[GameManager] All save data deleted.");
    }

    // -------------------------------------------------------------------------
    // Internal flow
    // -------------------------------------------------------------------------

    /// <summary>
    /// Opens the hero selection screen for the given level.
    /// HeroSelectionManager updates unlocked types and slot count.
    /// </summary>
    private void BeginSelectionPhase(int level)
    {
        _selectionManager.SetupForLevel(level);
        Debug.Log($"[GameManager] Selection phase — level {level}. " +
                  $"Max slots: {_selectionManager.MaxSelectable}.");
        OnSelectionPhaseStarted?.Invoke(level);
    }

    /// <summary>
    /// Spawns the player's chosen heroes and the enemy wave, then lets
    /// CombatSystem start the battle once all combatants are registered.
    /// </summary>
    private void StartCombat()
    {
        // Spawn enemies for this level
        EnemySpawner enemySpawner = FindObjectOfType<EnemySpawner>();
        if (enemySpawner != null)
        {
            enemySpawner.Level = _currentLevel;
            enemySpawner.SpawnEnemiesForLevel();
        }
        else
        {
            Debug.LogWarning("[GameManager] EnemySpawner not found.");
        }

        // Spawn only the heroes the player selected
        HeroSpawner heroSpawner = FindObjectOfType<HeroSpawner>();
        if (heroSpawner != null)
        {
            heroSpawner.SpawnSelectedHeroes(_selectionManager.SelectedHeroes);
        }
        else
        {
            Debug.LogWarning("[GameManager] HeroSpawner not found.");
        }

        OnCombatStarted?.Invoke();
        Debug.Log($"[GameManager] Combat started — level {_currentLevel}.");
    }

    /// <summary>
    /// Called by CombatSystem when the stage ends (win or lose).
    /// Pays out rewards, advances the level, and opens the next selection phase.
    /// </summary>
    private void HandleStageEnded()
    {
        _rewardCalculator.CalculateGoldsReward();

        // RewardInWallet calls CalculateGemsReward internally — do NOT call it separately.
        _rewardCalculator.RewardInWallet();

        _totalStagesWon++;
        OnStageEnded?.Invoke();

        if (_totalStagesWon >= 10)
        {
            _isLoopEnded    = true;
            _totalStagesWon = 0;
            _currentLevel   = 1;
            OnLoopEnded?.Invoke();
        }
        else
        {
            _currentLevel++;
        }

        // Open selection for the next level
        BeginSelectionPhase(_currentLevel);
    }
}