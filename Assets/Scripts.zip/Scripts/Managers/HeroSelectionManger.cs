using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Tracks which hero types are unlocked at each level and holds the player's
/// current selection. GameManager reads SelectedHeroes before spawning.
///
/// Unlock schedule:
///   Level 1  → 1 slot  (Fast only)
///   Level 2  → 1 slot  (Fast or Tank)
///   Level 3  → 2 slots (Fast, Tank, Ranged available)
///   Level 4  → 3 slots (all four available)
///   Level 5+ → 4 slots (full squad)
/// </summary>
public class HeroSelectionManager : MonoBehaviour
{
    public static HeroSelectionManager Instance { get; private set; }

    // -------------------------------------------------------------------------
    // Events
    // -------------------------------------------------------------------------

    /// <summary>Fired whenever the selection or unlock state changes.</summary>
    public event Action OnSelectionChanged;

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    /// <summary>Hero types the player is allowed to pick from this level.</summary>
    public List<HeroNums.VisualTypes> UnlockedTypes { get; private set; } = new();

    /// <summary>How many heroes the player may select this level.</summary>
    public int MaxSelectable { get; private set; } = 1;

    /// <summary>The hero types the player has actually chosen (ordered).</summary>
    public List<HeroNums.VisualTypes> SelectedHeroes { get; private set; } = new();

    // -------------------------------------------------------------------------
    // Unity Lifecycle
    // -------------------------------------------------------------------------

    private void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else Destroy(gameObject);
    }

    // -------------------------------------------------------------------------
    // Public API — called by GameManager
    // -------------------------------------------------------------------------

    /// <summary>
    /// Updates unlock state for the given level.
    /// Call this before showing the selection UI.
    /// </summary>
    public void SetupForLevel(int level)
    {
        UnlockedTypes.Clear();
        SelectedHeroes.Clear();

        if (level <= 1)
        {
            MaxSelectable = 1;
            UnlockedTypes.Add(HeroNums.VisualTypes.FAST);
        }
        else if (level == 2)
        {
            MaxSelectable = 1;
            UnlockedTypes.Add(HeroNums.VisualTypes.FAST);
            UnlockedTypes.Add(HeroNums.VisualTypes.TANK);
        }
        else if (level == 3)
        {
            MaxSelectable = 2;
            UnlockedTypes.Add(HeroNums.VisualTypes.FAST);
            UnlockedTypes.Add(HeroNums.VisualTypes.TANK);
            UnlockedTypes.Add(HeroNums.VisualTypes.RANGED);
        }
        else if (level == 4)
        {
            MaxSelectable = 3;
            UnlockedTypes.Add(HeroNums.VisualTypes.FAST);
            UnlockedTypes.Add(HeroNums.VisualTypes.TANK);
            UnlockedTypes.Add(HeroNums.VisualTypes.RANGED);
            UnlockedTypes.Add(HeroNums.VisualTypes.BOSS); // Support uses BOSS visual slot
        }
        else // level 5+
        {
            MaxSelectable = 4;
            UnlockedTypes.Add(HeroNums.VisualTypes.FAST);
            UnlockedTypes.Add(HeroNums.VisualTypes.TANK);
            UnlockedTypes.Add(HeroNums.VisualTypes.RANGED);
            UnlockedTypes.Add(HeroNums.VisualTypes.BOSS);
        }

        Debug.Log($"[HeroSelectionManager] Level {level}: {MaxSelectable} slot(s), " +
                  $"{UnlockedTypes.Count} hero type(s) unlocked.");

        OnSelectionChanged?.Invoke();
    }

    /// <summary>
    /// Toggle a hero type in/out of the selection.
    /// Returns false if the type is locked or slots are full.
    /// </summary>
    public bool ToggleHero(HeroNums.VisualTypes type)
    {
        if (!UnlockedTypes.Contains(type))
        {
            Debug.LogWarning($"[HeroSelectionManager] {type} is not unlocked yet.");
            return false;
        }

        if (SelectedHeroes.Contains(type))
        {
            SelectedHeroes.Remove(type);
            Debug.Log($"[HeroSelectionManager] Deselected {type}.");
            OnSelectionChanged?.Invoke();
            return true;
        }

        if (SelectedHeroes.Count >= MaxSelectable)
        {
            Debug.LogWarning($"[HeroSelectionManager] All {MaxSelectable} slot(s) already filled.");
            return false;
        }

        SelectedHeroes.Add(type);
        Debug.Log($"[HeroSelectionManager] Selected {type}. ({SelectedHeroes.Count}/{MaxSelectable})");
        OnSelectionChanged?.Invoke();
        return true;
    }

    /// <summary>True when the player has filled every available slot.</summary>
    public bool IsSelectionComplete => SelectedHeroes.Count == MaxSelectable;

    /// <summary>True when the player has selected at least one hero.</summary>
    public bool HasMinimumSelection => SelectedHeroes.Count > 0;
}