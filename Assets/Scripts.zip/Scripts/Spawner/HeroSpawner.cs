using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Spawns only the heroes the player selected via HeroSelectionManager.
/// GameManager calls SpawnSelectedHeroes() after the player confirms their picks.
/// </summary>
public class HeroSpawner : MonoBehaviour
{
    // ----------------------------------------------------------------------- --
    // Inspector
    // -------------------------------------------------------------------------

    [Header("References")]
    [SerializeField] private CombatSystem combatSystem;

    [Header("Hero Prefabs — assign one prefab per VisualType")]
    [SerializeField] private GameObject fastHeroPrefab;
    [SerializeField] private GameObject tankHeroPrefab;
    [SerializeField] private GameObject rangedHeroPrefab;
    [SerializeField] private GameObject supportHeroPrefab;   // maps to BOSS visual slot

    [Header("Spawn Points")]
    [Tooltip("Index matches HeroNums.SpawnPosition: 0=TOP_LEFT, 1=TOP_RIGHT, 2=BOTTOM_LEFT, 3=BOTTOM_RIGHT")]
    [SerializeField] private List<Transform> spawnPoints = new List<Transform>();

    // -------------------------------------------------------------------------
    // Unity Lifecycle
    // -------------------------------------------------------------------------

    void Start()
    {
        combatSystem = FindObjectOfType<CombatSystem>();
        // GameManager drives spawning — do NOT spawn here.
    }

    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------

    /// <summary>
    /// Spawns the heroes the player selected this level.
    /// GameManager calls this after the player confirms their selection.
    /// </summary>
    public void SpawnSelectedHeroes(List<HeroNums.VisualTypes> selectedTypes)
    {
        
        if (selectedTypes == null || selectedTypes.Count == 0)
        {
            Debug.LogWarning("[HeroSpawner] No heroes selected — nothing to spawn.");
            return;
        }

        combatSystem.SetExpectedHeroes(selectedTypes.Count);

        // Assign spawn positions in order: BOTTOM_LEFT, BOTTOM_RIGHT, TOP_LEFT, TOP_RIGHT
        HeroNums.SpawnPosition[] positionOrder =
        {
            HeroNums.SpawnPosition.BOTTOM_LEFT,
            HeroNums.SpawnPosition.BOTTOM_RIGHT,
            HeroNums.SpawnPosition.TOP_LEFT,
            HeroNums.SpawnPosition.TOP_RIGHT
        };

        for (int i = 0; i < selectedTypes.Count; i++)
        {
            GameObject prefab = GetPrefabForType(selectedTypes[i]);
            if (prefab == null)
            {
                Debug.LogError($"[HeroSpawner] No prefab assigned for type {selectedTypes[i]}!");
                continue;
            }

            HeroNums.SpawnPosition position = positionOrder[i % positionOrder.Length];
            Transform spawnPoint = GetSpawnPoint(position);

            GameObject hero = Instantiate(prefab, spawnPoint.position, spawnPoint.rotation);
            hero.name = $"{selectedTypes[i]}_Hero_{position}";

            Debug.Log($"[HeroSpawner] Spawned {hero.name} at {position}");
        }

        Debug.Log($"[HeroSpawner] {selectedTypes.Count} hero(es) spawned.");
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private GameObject GetPrefabForType(HeroNums.VisualTypes type)
    {
        switch (type)
        {
            case HeroNums.VisualTypes.FAST:   return fastHeroPrefab;
            case HeroNums.VisualTypes.TANK:   return tankHeroPrefab;
            case HeroNums.VisualTypes.RANGED: return rangedHeroPrefab;
            case HeroNums.VisualTypes.BOSS:   return supportHeroPrefab;
            default: return null;
        }
    }

    private Transform GetSpawnPoint(HeroNums.SpawnPosition position)
    {
        int index = (int)position;
        if (index >= 0 && index < spawnPoints.Count && spawnPoints[index] != null)
            return spawnPoints[index];

        Debug.LogWarning($"[HeroSpawner] No spawn point at index {index} ({position}), falling back to spawner position.");
        return transform;
    }
}