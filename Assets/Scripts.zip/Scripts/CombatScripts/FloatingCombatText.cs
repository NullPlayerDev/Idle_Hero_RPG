using System;
using TMPro;
using UnityEngine;
using DG.Tweening;
public class FloatingCombatText : MonoBehaviour
{
    public static FloatingCombatText Instance;
    [SerializeField]private TextMeshProUGUI text;
    private GameObject player;
    [SerializeField] private CombatSystem combatSystem;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
         player = combatSystem.GetRandomAttacker();
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Show(string message)
    {
        player = combatSystem.GetRandomAttacker();
        text.text = message;

        // Reset starting state
        transform.localPosition = player.transform.localPosition;
        text.alpha = 1f;

        // Move up + fade out at the same time
        Sequence seq = DOTween.Sequence();

        seq.Append(transform.DOLocalMoveY(transform.localPosition.y + 100f, 1f));
        seq.Join(text.DOFade(0f, 1f));

        // Destroy after animation
        seq.OnComplete(() => Destroy(gameObject));
    }
}
