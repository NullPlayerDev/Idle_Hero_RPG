using TMPro;
using UnityEngine;
using DG.Tweening;

public class FloatingCombatText : MonoBehaviour
{
    public static FloatingCombatText Instance;
    [SerializeField] private TextMeshProUGUI text;
    [SerializeField] private CombatSystem combatSystem;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void Show(string message)
    {
        // Fetch the attacker at call time (not once at Start — it changes every attack).
        GameObject attacker = combatSystem.GetRandomAttacker();
        if (attacker == null) return;

        text.text = message;

        // Use world position so both this transform and the attacker are in the same space.
        transform.position = attacker.transform.position;
        text.alpha = 1f;

        // Kill any in-progress tween on this object before starting a new one,
        // so rapid hits don't stack/break the animation.
        DOTween.Kill(transform);
        DOTween.Kill(text);

        Sequence seq = DOTween.Sequence();
        seq.Append(transform.DOMoveY(transform.position.y + 1f, 1f)); // world-space move
        seq.Join(text.DOFade(0f, 1f));
        // Do NOT Destroy — the singleton must stay alive for future hits.
    }
}
